# YOLOv8 ile Beyin Tümörü Nesne Algılama

Bu proje, Roboflow’dan alınan beyin tümörü veri seti ile YOLOv8 modelini kullanarak nesne algılama yapmaktadır.

## Kurulum

```bash
pip install -r requirements.txt
```

## Kullanım

- `yolov8_brain_tumor.ipynb` dosyasını açıp kendi Roboflow API anahtarınızla değiştirin.
- Notebook’u çalıştırarak veri indirme, eğitim ve test işlemlerini gerçekleştirin.

## Veri Seti

- [Brain Tumor Detection Dataset - Roboflow](https://universe.roboflow.com/iotseecs/brain-tumor-yzzav/dataset/1)

## Teknolojiler

- YOLOv8 (Ultralytics)
- Roboflow
- OpenCV
- Matplotlib

---

### Kod ve eğitim süreci YouTube kanalımda detaylıca anlatılmıştır.
